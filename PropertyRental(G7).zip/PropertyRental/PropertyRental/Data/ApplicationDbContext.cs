﻿using Microsoft.EntityFrameworkCore;
using PropertyRental.Models;
using System.Collections.Generic;

namespace PropertyRental.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Property> Properties { get; set; }
        public DbSet<Rental> Rentals { get; set; }
    }
}
