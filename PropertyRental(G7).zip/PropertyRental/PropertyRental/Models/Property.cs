using System;

namespace PropertyRental.Models
{
    public class Property
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public decimal Rent { get; set; }
        public bool IsAvailable { get; set; }
    }
}
