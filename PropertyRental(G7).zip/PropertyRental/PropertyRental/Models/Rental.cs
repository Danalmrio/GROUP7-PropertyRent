using System;

namespace PropertyRental.Models
{
    public class Rental
    {
        public int Id { get; set; }
        public int PropertyId { get; set; }
        public string TenantName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
